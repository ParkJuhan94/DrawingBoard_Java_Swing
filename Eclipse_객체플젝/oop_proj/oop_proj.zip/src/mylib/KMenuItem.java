package mylib;

import java.awt.event.MouseEvent;

public class KMenuItem extends KAbstractButton{
	
	public KMenuItem(String text) {
		super(text);
		visible = false;
	}
		
}