package mylib;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public interface KActionListener extends ActionListener{

	void actionPerformed(ActionEvent e);

}
