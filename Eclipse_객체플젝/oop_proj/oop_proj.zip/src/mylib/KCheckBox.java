package mylib;

public class KCheckBox {

}
